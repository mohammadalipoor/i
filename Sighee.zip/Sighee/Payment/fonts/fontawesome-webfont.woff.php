﻿<!DOCTYPE html><html lang="fa-IR" xmlns="../external.html?link=http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.minatavakoli.ir/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Dec 2018 04:15:43 GMT -->
<!-- Added by HTTrack -->
<!-- Mirrored from sighe-halal.tk/ by HTTrack Website Copier/3.x [XR&CO'2017], Fri, 28 Dec 2018 09:08:44 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head><title>صیغه موقت|صیغه دائم|صیغه تمام ایران</title>
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="robots" content="noindex, follow" />
<meta http-equiv="cache-control" content="cache" />
<meta http-equiv="content-language" content="fa" />
<meta http-equiv="revisit-after" content="1 Days" />
<link type="text/css" rel="stylesheet" href="css/indexStyleSheet.css" />
<link type="text/css" rel="stylesheet"href="css/mobile.css" media="only screen and (min-width: 100px) and (max-width: 380px)" />
</head><body class="index">
<nav><ul>
<li><a href="index-2.html">خانه</a></li>
<li><a href="faq.html">سوالات متداول</a>
<li><a href="aboutus.html">درباره ما</a>
<li><a href="contactus.html">تماس با ما</a></li>
</ul></nav>
<h1>صیغه دائم و موقت تمام شهرهای ایران</h1>
<form action="../payment=11543459sh.php?amount=50%2C000" method="post">
<center>
<input type="text" name="neme" placeholder="نام شما" title="نام خود را درج نمایید" maxlength="50" autocomplete="off"/><br />
<input type="text" name="city" list="city" placeholder="استان" title="استان درخواستی خود را درج نمایید" class="adad" maxlength="15" autocomplete="off"/><br />
<datalist id="city">
<option value="آذربایجان شرقی">
<option value="	آذربایجان غربی">
<option value="اردبیل">
<option value="اصفهان">
<option value="البرز">
<option value="ایلام">
<option value="بوشهر">
<option value="تهران">
<option value="چهارمحال و بختیاری">
<option value="خراسان جنوبی">
<option value="خراسان رضوی">
<option value="خراسان شمالی">
<option value="خوزستان">
<option value="زنجان">
<option value="سمنان">
<option value="سیستان و بلوچستان">
<option value="فارس">
<option value="قزوین">
<option value="قم">
<option value="کردستان">
<option value="کرمان">
<option value="کرمانشاه">
<option value="کهگیلویه و بویراحمد">
<option value="گلستان">
<option value="لرستان">
<option value="مازندران">
<option value="مرکزی">
<option value="هرمزگان">
<option value="همدان">
<option value="یزد">
</datalist>
<input type="text" name="city2" placeholder="شهر" title="شهرستان درخواستی خود را درج نمایید" maxlength="15" autocomplete="off" /><br />
<input type="number" name="age" list="age"  class="adad" placeholder="سن" title="سن صیغه درخواستی خود را درج نمایید" autocomplete="off" min="20" max="45" />
<datalist id="age">
<option value="20">
<option value="21">
<option value="22">
<option value="23">
<option value="24">
<option value="25">
<option value="26">
<option value="27">
<option value="28">
<option value="29">
<option value="30">
<option value="31">
<option value="32">
<option value="33">
<option value="34">
<option value="35">
<option value="36">
<option value="37">
<option value="38">
<option value="39">
<option value="40">
<option value="41">
<option value="42">
<option value="43">
<option value="44">
<option value="45">
</datalist><br />
<p style="color:white">تعرفه (5000 تومان)</p><br />
<input type="submit" name="submit" value="ارسال" /> 
</center></form>
<footer>این وب سایت دارای مجوز از وزرات فرهنگ و ارشاد ایران فعالیت مینماید .</footer>

<!-- Mirrored from www.minatavakoli.ir/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Dec 2018 04:15:45 GMT -->

<!-- Mirrored from sighe-halal.tk/ by HTTrack Website Copier/3.x [XR&CO'2017], Fri, 28 Dec 2018 09:08:51 GMT -->
</html>